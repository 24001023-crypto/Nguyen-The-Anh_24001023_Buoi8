﻿using System;
using System.Collections.Generic;
using System.Linq;
using Lab06_ThreeLayerMemory.Models;

namespace Lab06_ThreeLayerMemory.DAL
{
    public class SinhVienDAL : ISinhVienDAL
    {
        // Kho dữ liệu giả lập: tồn tại trong thời gian chương trình đang chạy.
        private readonly List<SinhVien> _data = new List<SinhVien>();

        public SinhVienDAL()
        {
            // 3 khoa, mỗi khoa đúng 3 sinh viên khi khởi động.
            _data.Add(new SinhVien("SV01", "Nguyễn An", new DateTime(2006, 2, 24), "Nam", "CNTT", 8.2));
            _data.Add(new SinhVien("SV02", "Trần Bình", new DateTime(2006, 5, 12), "Nam", "CNTT", 7.0));
            _data.Add(new SinhVien("SV03", "Lê Lan Anh", new DateTime(2006, 9, 18), "Nữ", "CNTT", 8.8));
            _data.Add(new SinhVien("SV04", "Phạm Minh Đức", new DateTime(2005, 3, 15), "Nam", "OTO", 7.5));
            _data.Add(new SinhVien("SV05", "Vũ Hoàng Nam", new DateTime(2006, 7, 9), "Nam", "OTO", 6.8));
            _data.Add(new SinhVien("SV06", "Đỗ Thu Hà", new DateTime(2006, 12, 20), "Nữ", "OTO", 8.0));
            _data.Add(new SinhVien("SV07", "Nguyễn Ngọc Mai", new DateTime(2006, 1, 8), "Nữ", "KT", 9.1));
            _data.Add(new SinhVien("SV08", "Bùi Quang Huy", new DateTime(2005, 8, 25), "Nam", "KT", 7.2));
            _data.Add(new SinhVien("SV09", "Hoàng Minh Châu", new DateTime(2006, 11, 3), "Nữ", "KT", 8.5));
        }

        public List<SinhVien> GetAll()
        {
            // Sao chép cả danh sách và từng phần tử, không trả kho gốc ra ngoài.
            return _data.Select(sv => sv.SaoChep()).ToList();
        }

        public SinhVien GetById(string maSV)
        {
            SinhVien sv = _data.FirstOrDefault(x => string.Equals(
                x.MaSV, maSV, StringComparison.OrdinalIgnoreCase));
            return sv == null ? null : sv.SaoChep();
        }

        public void Add(SinhVien sv)
        {
            _data.Add(sv.SaoChep());
        }

        public void Update(SinhVien sv)
        {
            int index = _data.FindIndex(x => string.Equals(
                x.MaSV, sv.MaSV, StringComparison.OrdinalIgnoreCase));
            if (index < 0)
                throw new InvalidOperationException("Sinh viên không còn tồn tại.");
            _data[index] = sv.SaoChep();
        }

        public void Delete(string maSV)
        {
            int index = _data.FindIndex(x => string.Equals(
                x.MaSV, maSV, StringComparison.OrdinalIgnoreCase));
            if (index < 0)
                throw new InvalidOperationException("Sinh viên không còn tồn tại.");
            _data.RemoveAt(index);
        }
    }
}
