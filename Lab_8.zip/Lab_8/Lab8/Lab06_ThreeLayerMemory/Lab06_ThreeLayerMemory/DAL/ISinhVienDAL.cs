﻿using System.Collections.Generic;
using Lab06_ThreeLayerMemory.Models;

namespace Lab06_ThreeLayerMemory.DAL
{
    // Lab 7: tạo SinhVienSqlDAL thực hiện cùng hợp đồng này bằng ADO.NET.
    public interface ISinhVienDAL
    {
        List<SinhVien> GetAll();
        SinhVien GetById(string maSV);
        void Add(SinhVien sv);
        void Update(SinhVien sv);
        void Delete(string maSV);
    }
}
