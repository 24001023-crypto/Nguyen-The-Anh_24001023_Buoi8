﻿using System;

namespace Lab06_ThreeLayerMemory.Models
{
    public class SinhVien
    {
        public string MaSV { get; set; }
        public string HoTen { get; set; }
        public DateTime NgaySinh { get; set; }
        public string GioiTinh { get; set; }
        public string MaKhoa { get; set; }
        public string TenKhoa { get; set; }
        public double DiemTB { get; set; }

        public SinhVien() { }

        // Giữ constructor bốn tham số giống code mẫu của đề bài.
        // Khi lưu qua BUS, cần bổ sung MaKhoa và GioiTinh hợp lệ.
        public SinhVien(string maSV, string hoTen, DateTime ngaySinh, double diemTB)
            : this(maSV, hoTen, ngaySinh, "Nam", "", diemTB) { }

        public SinhVien(string maSV, string hoTen, DateTime ngaySinh,
            string gioiTinh, string maKhoa, double diemTB)
        {
            MaSV = maSV;
            HoTen = hoTen;
            NgaySinh = ngaySinh.Date;
            GioiTinh = gioiTinh;
            MaKhoa = maKhoa;
            DiemTB = diemTB;
            TenKhoa = "";
        }

        // Trả bản sao để GUI không sửa được trực tiếp đối tượng trong DAL.
        public SinhVien SaoChep()
        {
            return new SinhVien(MaSV, HoTen, NgaySinh, GioiTinh, MaKhoa, DiemTB)
            {
                TenKhoa = this.TenKhoa
            };
        }
    }
}
