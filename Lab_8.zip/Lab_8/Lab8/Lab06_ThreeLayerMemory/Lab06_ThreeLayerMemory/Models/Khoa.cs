﻿namespace Lab06_ThreeLayerMemory.Models
{
    // Model chỉ mô tả dữ liệu; không biết Form hay cách lưu dữ liệu.
    public class Khoa
    {
        public string MaKhoa { get; set; }
        public string TenKhoa { get; set; }

        public Khoa() { }

        public Khoa(string maKhoa, string tenKhoa)
        {
            MaKhoa = maKhoa;
            TenKhoa = tenKhoa;
        }

        public Khoa SaoChep()
        {
            return new Khoa(MaKhoa, TenKhoa);
        }
    }
}
