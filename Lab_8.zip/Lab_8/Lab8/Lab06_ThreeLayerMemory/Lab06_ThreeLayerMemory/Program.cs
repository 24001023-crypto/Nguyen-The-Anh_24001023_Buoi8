﻿using System;
using System.Windows.Forms;
using Lab06_ThreeLayerMemory.BUS;
using Lab06_ThreeLayerMemory.DAL;
using Lab06_ThreeLayerMemory.GUI;

namespace Lab06_ThreeLayerMemory
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Chỉ tạo một kho dữ liệu cho toàn bộ phiên chạy.
            IKhoaDAL khoaDAL = new KhoaDAL();
            ISinhVienDAL sinhVienDAL = new SinhVienDAL();
            KhoaBUS khoaBUS = new KhoaBUS(khoaDAL);
            SinhVienBUS sinhVienBUS = new SinhVienBUS(sinhVienDAL, khoaDAL);

            // Form nhận BUS; không khởi tạo hoặc gọi DAL.
            Application.Run(new frmMain(sinhVienBUS, khoaBUS));
        }
    }
}
