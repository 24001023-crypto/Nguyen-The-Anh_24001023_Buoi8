﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab06_ThreeLayerMemory
{
    internal class DbConnectionFactory
    {
        private const string ConnectionString =
            @"Data Source=.;Initial Catalog=QLSinhVien;Integrated Security=True;TrustServerCertificate=True";

        public static SqlConnection Create()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}
