# Lab06_ThreeLayerMemory

Ứng dụng quản lý sinh viên bằng C# Windows Forms, dùng .NET Framework 4.8 và Visual Studio 2022. Project thực hiện 5 bài có hướng dẫn của Lab 6, có chú thích tiếng Việt trong các phần xử lý chính.

## 1. Mở và chạy

1. Giải nén toàn bộ file ZIP bằng **Extract All / Giải nén tất cả**. Không mở project trực tiếp bên trong file ZIP.
2. Mở **Lab06_ThreeLayerMemory.sln** ở thư mục ngoài cùng bằng Visual Studio 2022.
3. Trong Solution Explorer, nếu cần, nhấn phải project **Lab06_ThreeLayerMemory** → **Set as Startup Project**.
4. Nhấn **F5** hoặc nút **Start / Bắt đầu**. Form chính mở ngay danh sách 9 sinh viên.

Máy cần có workload **.NET desktop development** và thành phần **.NET Framework 4.8 targeting pack** trong Visual Studio Installer. Project không dùng NuGet, không cần SQL Server hay chuỗi kết nối ở Lab này.

## 2. Xem giao diện kéo thả

Trong Solution Explorer: mở project → thư mục **GUI** → nhấn phải **frmDanhSach.cs** → **View Designer / Xem trình thiết kế**, hoặc chọn file rồi nhấn **Shift + F7**.

Các Form khác cũng mở tương tự: `frmMain.cs`, `frmSinhVien.cs`, `frmChiTietSinhVien.cs`, `frmGioiThieu.cs`. Mỗi Form có đủ `.cs`, `.Designer.cs` và `.resx`.

Không chọn riêng file `.Designer.cs` để tìm màn hình thiết kế; chọn file Form `.cs` ở cấp trên. Nếu không thấy Solution Explorer, mở **View → Solution Explorer** hoặc **Ctrl + Alt + L**.

## 3. Thao tác

| Thao tác | Cách thực hiện |
|---|---|
| Xem bảng sinh viên | Chọn tab **Bảng sinh viên (DataGridView)**. |
| Xem ListView | Chọn tab **Danh sách chi tiết (ListView)**; có mã, họ tên, khoa, điểm. |
| Xem theo khoa | Chọn node sinh viên trên cây bên phải; chi tiết hiện phía dưới. |
| Thêm | Bấm **Thêm**, nhập các trường, bấm **Lưu**; có thể dùng **Ctrl + N**. |
| Sửa | Chọn sinh viên ở bảng, danh sách hoặc cây → **Sửa** → **Lưu**. Mã sinh viên giữ nguyên. |
| Xóa | Chọn sinh viên → **Xóa** → **Yes / Có** để xác nhận. |
| Xem chi tiết | Bấm **Xem chi tiết** hoặc nháy đúp sinh viên. |
| Hủy nhập | Bấm **Hủy**, nhấn **Esc** hoặc đóng Form nhập. |
| Làm mới | Nạp lại dữ liệu hiện có trong bộ nhớ, không khôi phục dữ liệu mẫu. |
| Giới thiệu | Menu **Trợ giúp → Giới thiệu**. |
| Thoát | Menu **Hệ thống → Thoát** hoặc đóng cửa sổ chính. |

Sau khi thêm, sửa hoặc xóa, cả ba vùng hiển thị đều được cập nhật. Khi đổi khoa của sinh viên, node sinh viên chuyển sang khoa mới.

**Dữ liệu chỉ tồn tại trong bộ nhớ:** thoát chương trình sẽ mất các thay đổi. Chạy lại sẽ tạo dữ liệu mẫu gồm 3 khoa, mỗi khoa 3 sinh viên. Đây là hành vi đúng của Lab 6.

## 4. Các lớp và thư mục

| Vị trí | Nhiệm vụ |
|---|---|
| `Models/SinhVien.cs` | Mã, họ tên, ngày sinh, giới tính, mã khoa, tên khoa, điểm TB. |
| `Models/Khoa.cs` | Mã khoa và tên khoa. |
| `DAL/SinhVienDAL.cs` | Giữ `List<SinhVien>` trong bộ nhớ; đọc, thêm, sửa, xóa. |
| `DAL/KhoaDAL.cs` | Dữ liệu mẫu 3 khoa. |
| `DAL/ISinhVienDAL.cs`, `DAL/IKhoaDAL.cs` | Hợp đồng để thay cách lưu dữ liệu ở Lab 7. |
| `BUS/SinhVienBUS.cs` | Kiểm tra nghiệp vụ và gọi DAL. |
| `BUS/KhoaBUS.cs` | Cung cấp khoa cho giao diện qua BUS. |
| `GUI/frmMain.cs` | MenuStrip, StatusStrip, khởi tạo vùng danh sách. |
| `GUI/frmDanhSach.cs` | BindingList, BindingSource, DataGridView, ListView, TreeView và các nút CRUD. |
| `GUI/frmSinhVien.cs` | Form dùng chung để thêm/sửa, ErrorProvider, kiểm tra định dạng điểm. |
| `GUI/frmChiTietSinhVien.cs` | Nhận sinh viên qua constructor và hiển thị chi tiết. |
| `GUI/frmGioiThieu.cs` | Thông tin bài thực hành. |
| `Program.cs` | Tạo một DAL dùng chung, nối BUS với DAL và chạy Form chính. |

Các tầng được chia bằng **thư mục trong cùng một project**, đúng lựa chọn “thư mục hoặc project” của đề bài. Form chỉ gọi BUS; không gọi DAL hay truy cập danh sách gốc của DAL.

## 5. Bài tập nằm ở đâu?

| Bài | Phần mã để trình bày |
|---|---|
| 1. BindingList trên DataGridView | `_ds`, constructor và `NapDuLieu()` trong `frmDanhSach.cs`; cấu hình cột trong Designer. |
| 2. Thêm, sửa, xóa | Các nút ở `frmDanhSach.cs`, nút Lưu trong `frmSinhVien.cs`, các hàm `Add/Update/Delete` của BUS và DAL. |
| 3. ListView dạng Details | `LoadListView()`; thêm cả cột khoa để đủ yêu cầu đề. |
| 4. TreeView khoa – sinh viên | `LoadTree()`, `tvKhoa_AfterSelect()`, `ChonSinhVien()`. |
| 5. GUI – BUS – DAL giả lập | Các thư mục `GUI`, `BUS`, `DAL` và chỗ ghép đối tượng trong `Program.cs`. |

Xem **GIAI_THICH_CODE.md** để ôn cách giải thích các phần này.

## 6. Kịch bản demo nhanh

1. Chạy ứng dụng, chỉ ra 9 sinh viên và 3 khoa.
2. Chuyển sang tab ListView, chỉ ra đủ 4 cột.
3. Chọn `SV06` trong cây để xem chi tiết; nháy đúp để mở Form chi tiết.
4. Thêm `SV10`, tên `Nguyễn Minh`, ngày sinh `24/02/2006`, khoa CNTT, điểm `8,5`.
5. Thử thêm mã `sv10`: chương trình báo trùng mã, kể cả khác chữ hoa/thường.
6. Sửa `SV10`, đổi khoa sang Kinh tế và điểm thành `9.25`; quan sát cây và ListView cập nhật.
7. Thử điểm `11` hoặc dán chữ vào ô điểm rồi Lưu: xuất hiện thông báo, dữ liệu không bị ghi sai.
8. Xóa `SV10`; bảng, danh sách và cây cùng cập nhật.
9. Mở mã nguồn, lần theo Form → BUS → DAL; chỉ ra nơi kiểm tra trùng mã trong BUS.

## 7. Chuẩn bị cho Lab 7

Tạo `SinhVienSqlDAL : ISinhVienDAL` và `KhoaSqlDAL : IKhoaDAL`, triển khai các phương thức bằng ADO.NET. Trong `Program.cs`, thay đối tượng DAL bộ nhớ bằng DAL SQL; tiếp tục truyền chúng vào BUS như hiện tại.

Giữ hợp đồng model và phương thức thì Form vẫn gọi BUS như cũ. Lab 7 cần bổ sung bảng, kết nối, câu lệnh có tham số và xử lý lỗi truy cập cơ sở dữ liệu. Các phần SQL đó chưa nằm trong phạm vi Lab 6.
