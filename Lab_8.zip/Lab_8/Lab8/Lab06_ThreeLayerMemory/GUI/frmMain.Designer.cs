﻿namespace Lab06_ThreeLayerMemory.GUI
{
    partial class frmMain
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlNoiDung = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuHeThong = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSinhVien = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTroGiup = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuThoat = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDanhSach = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuThem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuGioiThieu = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblTrangThai = new System.Windows.Forms.ToolStripStatusLabel();
            this.pnlNoiDung.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            this.pnlNoiDung.Name = "pnlNoiDung";
            this.Controls.Add(this.pnlNoiDung);
            this.pnlNoiDung.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip1.Name = "menuStrip1";
            this.Controls.Add(this.menuStrip1);
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Top;
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(10, 4, 0, 4);
            this.mnuHeThong.Name = "mnuHeThong";
            this.mnuHeThong.Text = "Hệ thống";
            this.mnuSinhVien.Name = "mnuSinhVien";
            this.mnuSinhVien.Text = "Sinh viên";
            this.mnuTroGiup.Name = "mnuTroGiup";
            this.mnuTroGiup.Text = "Trợ giúp";
            this.mnuThoat.Name = "mnuThoat";
            this.mnuThoat.Text = "Thoát";
            this.mnuDanhSach.Name = "mnuDanhSach";
            this.mnuDanhSach.Text = "Danh sách sinh viên";
            this.mnuThem.Name = "mnuThem";
            this.mnuThem.Text = "Thêm sinh viên";
            this.mnuGioiThieu.Name = "mnuGioiThieu";
            this.mnuGioiThieu.Text = "Giới thiệu";
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuHeThong, this.mnuSinhVien, this.mnuTroGiup });
            this.mnuHeThong.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuThoat });
            this.mnuSinhVien.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuDanhSach, this.mnuThem });
            this.mnuTroGiup.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuGioiThieu });
            this.mnuThem.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N;
            this.statusStrip1.Name = "statusStrip1";
            this.Controls.Add(this.statusStrip1);
            this.lblTrangThai.Name = "lblTrangThai";
            this.lblTrangThai.Text = "Lab 06  |  Dữ liệu chỉ lưu trong phiên chạy; thoát ứng dụng sẽ mất thay đổi.";
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.lblTrangThai });
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(1080, 650);
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1200, 720);
            this.Name = "frmMain";
            this.Text = "Lab 06 - Quản lý sinh viên";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.mnuThoat.Click += new System.EventHandler(this.mnuThoat_Click);
            this.mnuDanhSach.Click += new System.EventHandler(this.mnuDanhSach_Click);
            this.mnuThem.Click += new System.EventHandler(this.mnuThem_Click);
            this.mnuGioiThieu.Click += new System.EventHandler(this.mnuGioiThieu_Click);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.pnlNoiDung.ResumeLayout(false);
            this.pnlNoiDung.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        #endregion

        private System.Windows.Forms.Panel pnlNoiDung;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuHeThong;
        private System.Windows.Forms.ToolStripMenuItem mnuSinhVien;
        private System.Windows.Forms.ToolStripMenuItem mnuTroGiup;
        private System.Windows.Forms.ToolStripMenuItem mnuThoat;
        private System.Windows.Forms.ToolStripMenuItem mnuDanhSach;
        private System.Windows.Forms.ToolStripMenuItem mnuThem;
        private System.Windows.Forms.ToolStripMenuItem mnuGioiThieu;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel lblTrangThai;
    }
}
