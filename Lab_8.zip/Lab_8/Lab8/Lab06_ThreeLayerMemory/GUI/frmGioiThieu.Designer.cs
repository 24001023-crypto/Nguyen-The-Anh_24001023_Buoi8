﻿namespace Lab06_ThreeLayerMemory.GUI
{
    partial class frmGioiThieu
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.lblNoiDung = new System.Windows.Forms.Label();
            this.btnDong = new System.Windows.Forms.Button();
            this.SuspendLayout();
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Location = new System.Drawing.Point(25, 20);
            this.lblTieuDe.Size = new System.Drawing.Size(590, 40);
            this.lblTieuDe.Text = "LAB 06 • QUẢN LÝ SINH VIÊN";
            this.Controls.Add(this.lblTieuDe);
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.FromArgb(31, 78, 121);
            this.lblNoiDung.Name = "lblNoiDung";
            this.lblNoiDung.Location = new System.Drawing.Point(28, 85);
            this.lblNoiDung.Size = new System.Drawing.Size(585, 190);
            this.lblNoiDung.Text = "Học phần: Lập trình .NET - IT3212\n\n• DataGridView, ListView và TreeView hiển thị cùng danh sách.\n• BindingList<SinhVien> kết hợp BindingSource để liên kết dữ liệu.\n• Thêm, sửa, xóa thông qua các lớp GUI - BUS - DAL.\n• Dữ liệu mẫu: 3 khoa, 9 sinh viên.\n\nDữ liệu chỉ tồn tại trong bộ nhớ. Mở lại ứng dụng sẽ có dữ liệu mẫu.";
            this.Controls.Add(this.lblNoiDung);
            this.btnDong.Name = "btnDong";
            this.btnDong.Location = new System.Drawing.Point(490, 285);
            this.btnDong.Size = new System.Drawing.Size(120, 34);
            this.btnDong.Text = "Đóng";
            this.Controls.Add(this.btnDong);
            this.btnDong.TabIndex = 0;
            this.btnDong.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.AcceptButton = this.btnDong;
            this.CancelButton = this.btnDong;
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(640, 335);
            this.Name = "frmGioiThieu";
            this.Text = "Giới thiệu";
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ShowInTaskbar = false;
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Label lblNoiDung;
        private System.Windows.Forms.Button btnDong;
    }
}
