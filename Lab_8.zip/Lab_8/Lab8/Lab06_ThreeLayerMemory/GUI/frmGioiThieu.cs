﻿using System.Windows.Forms;

namespace Lab06_ThreeLayerMemory.GUI
{
    public partial class frmGioiThieu : Form
    {
        public frmGioiThieu() { InitializeComponent(); }
    }
}
