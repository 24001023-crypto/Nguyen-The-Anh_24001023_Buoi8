﻿using System.Windows.Forms;
using Lab06_ThreeLayerMemory.Models;

namespace Lab06_ThreeLayerMemory.GUI
{
    public partial class frmChiTietSinhVien : Form
    {
        public frmChiTietSinhVien() { InitializeComponent(); }

        // Truyền dữ liệu giữa các Form bằng constructor, tiếp nối Lab 5.
        public frmChiTietSinhVien(SinhVien sv) : this()
        {
            lblMa.Text = sv.MaSV;
            lblTen.Text = sv.HoTen;
            lblNgay.Text = sv.NgaySinh.ToString("dd/MM/yyyy");
            lblGioi.Text = sv.GioiTinh;
            lblKhoa.Text = sv.TenKhoa;
            lblDiem.Text = sv.DiemTB.ToString("N2");
        }
    }
}
