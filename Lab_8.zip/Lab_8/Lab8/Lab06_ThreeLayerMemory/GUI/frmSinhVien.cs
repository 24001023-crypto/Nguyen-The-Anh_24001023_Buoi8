﻿using System;
using System.Globalization;
using System.Windows.Forms;
using Lab06_ThreeLayerMemory.BUS;
using Lab06_ThreeLayerMemory.Models;

namespace Lab06_ThreeLayerMemory.GUI
{
    public partial class frmSinhVien : Form
    {
        private readonly SinhVienBUS _sinhVienBUS;
        private readonly KhoaBUS _khoaBUS;
        private readonly SinhVien _sinhVienSua;

        public string MaDaLuu { get; private set; }

        // Constructor không tham số giúp Visual Studio mở được Designer.
        public frmSinhVien()
        {
            InitializeComponent();
        }

        public frmSinhVien(SinhVienBUS sinhVienBUS, KhoaBUS khoaBUS, SinhVien sinhVienSua)
            : this()
        {
            _sinhVienBUS = sinhVienBUS;
            _khoaBUS = khoaBUS;
            _sinhVienSua = sinhVienSua;
        }

        private void frmSinhVien_Load(object sender, EventArgs e)
        {
            if (_khoaBUS == null) return; // Không truy cập dữ liệu khi mở Designer.
            cboKhoa.DisplayMember = "TenKhoa";
            cboKhoa.ValueMember = "MaKhoa";
            cboKhoa.DataSource = _khoaBUS.GetAll();
            dtpNgaySinh.MinDate = new DateTime(1900, 1, 1);
            dtpNgaySinh.MaxDate = DateTime.Today;
            dtpNgaySinh.Value = DateTime.Today.AddYears(-18);

            bool dangSua = _sinhVienSua != null;
            Text = dangSua ? "Sửa sinh viên" : "Thêm sinh viên";
            lblTieuDe.Text = dangSua ? "SỬA SINH VIÊN" : "THÊM SINH VIÊN";
            txtMaSV.ReadOnly = dangSua; // Mã là khóa định danh, không đổi khi sửa.

            if (dangSua)
            {
                txtMaSV.Text = _sinhVienSua.MaSV;
                txtHoTen.Text = _sinhVienSua.HoTen;
                dtpNgaySinh.Value = _sinhVienSua.NgaySinh;
                radNam.Checked = _sinhVienSua.GioiTinh == "Nam";
                radNu.Checked = _sinhVienSua.GioiTinh == "Nữ";
                cboKhoa.SelectedValue = _sinhVienSua.MaKhoa;
                txtDiemTB.Text = _sinhVienSua.DiemTB.ToString("0.##", CultureInfo.InvariantCulture);
            }
            else
            {
                radNam.Checked = true;
                txtDiemTB.Text = "0";
            }
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (_sinhVienBUS == null) return;
            errorProvider1.Clear();

            // Chấp nhận cả 8.5 và 8,5; TryParse không làm ứng dụng bị lỗi khi nhập chữ.
            double diem;
            string chuoiDiem = txtDiemTB.Text.Trim().Replace(',', '.');
            if (!double.TryParse(chuoiDiem,
                NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign,
                CultureInfo.InvariantCulture, out diem))
            {
                BaoLoi(txtDiemTB, "Nhập điểm dạng số, ví dụ 8.5 hoặc 8,5.");
                return;
            }

            SinhVien sv = new SinhVien(txtMaSV.Text, txtHoTen.Text,
                dtpNgaySinh.Value, radNam.Checked ? "Nam" : "Nữ",
                Convert.ToString(cboKhoa.SelectedValue), diem);

            try
            {
                // Form chỉ gọi BUS. BUS mới kiểm tra nghiệp vụ rồi gọi DAL.
                if (_sinhVienSua == null) _sinhVienBUS.Add(sv);
                else _sinhVienBUS.Update(_sinhVienSua.MaSV, sv);

                MaDaLuu = sv.MaSV.Trim().ToUpperInvariant();
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (ArgumentException ex)
            {
                // ParamName do BUS gửi về cho biết ô nhập nào đang sai.
                Control oNhap = txtMaSV;
                switch (ex.ParamName)
                {
                    case "HoTen": oNhap = txtHoTen; break;
                    case "NgaySinh": oNhap = dtpNgaySinh; break;
                    case "GioiTinh": oNhap = grpGioiTinh; break;
                    case "MaKhoa": oNhap = cboKhoa; break;
                    case "DiemTB": oNhap = txtDiemTB; break;
                }
                BaoLoi(oNhap, ex.Message.Split(new[] { '\r', '\n' })[0]);
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(this, ex.Message, "Không thể lưu",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BaoLoi(Control control, string thongBao)
        {
            errorProvider1.SetError(control, thongBao);
            lblLoi.Text = thongBao;
            control.Focus();
        }

        private void DuLieu_Changed(object sender, EventArgs e)
        {
            Control control = sender as Control;
            if (control != null) errorProvider1.SetError(control, "");
            lblLoi.Text = "";
        }

        private void txtDiemTB_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Dán nội dung vẫn được kiểm tra lại bằng TryParse lúc bấm Lưu.
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)
                && e.KeyChar != '.' && e.KeyChar != ',')
                e.Handled = true;
        }
    }
}
