﻿using System;
using System.Windows.Forms;
using Lab06_ThreeLayerMemory.BUS;

namespace Lab06_ThreeLayerMemory.GUI
{
    public partial class frmMain : Form
    {
        private readonly SinhVienBUS _sinhVienBUS;
        private readonly KhoaBUS _khoaBUS;
        private frmDanhSach _danhSach;

        public frmMain() { InitializeComponent(); }

        public frmMain(SinhVienBUS sinhVienBUS, KhoaBUS khoaBUS) : this()
        {
            _sinhVienBUS = sinhVienBUS;
            _khoaBUS = khoaBUS;
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            if (_sinhVienBUS == null) return;
            _danhSach = new frmDanhSach(_sinhVienBUS, _khoaBUS);
            _danhSach.TopLevel = false;
            _danhSach.FormBorderStyle = FormBorderStyle.None;
            _danhSach.Dock = DockStyle.Fill;
            pnlNoiDung.Controls.Add(_danhSach);
            _danhSach.Show(); // Mở danh sách ngay khi chạy, không cần tìm trong menu.
        }

        private void mnuDanhSach_Click(object sender, EventArgs e)
        {
            if (_danhSach != null) _danhSach.BringToFront();
        }

        private void mnuThem_Click(object sender, EventArgs e)
        {
            if (_danhSach != null) _danhSach.ThemSinhVien();
        }

        private void mnuGioiThieu_Click(object sender, EventArgs e)
        {
            using (frmGioiThieu form = new frmGioiThieu()) form.ShowDialog(this);
        }

        private void mnuThoat_Click(object sender, EventArgs e) { Close(); }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Chỉ hỏi khi người dùng chủ động đóng, không cản Windows tắt máy.
            if (_sinhVienBUS == null || e.CloseReason != CloseReason.UserClosing) return;
            e.Cancel = MessageBox.Show(this,
                "Dữ liệu chỉ lưu trong bộ nhớ và sẽ mất khi thoát. Bạn muốn thoát?",
                "Thoát chương trình", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2) != DialogResult.Yes;
        }
    }
}
