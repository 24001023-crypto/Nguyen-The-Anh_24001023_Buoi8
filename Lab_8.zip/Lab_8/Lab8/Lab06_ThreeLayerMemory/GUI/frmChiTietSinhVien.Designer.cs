﻿namespace Lab06_ThreeLayerMemory.GUI
{
    partial class frmChiTietSinhVien
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.captionMa = new System.Windows.Forms.Label();
            this.lblMa = new System.Windows.Forms.Label();
            this.captionTen = new System.Windows.Forms.Label();
            this.lblTen = new System.Windows.Forms.Label();
            this.captionNgay = new System.Windows.Forms.Label();
            this.lblNgay = new System.Windows.Forms.Label();
            this.captionGioi = new System.Windows.Forms.Label();
            this.lblGioi = new System.Windows.Forms.Label();
            this.captionKhoa = new System.Windows.Forms.Label();
            this.lblKhoa = new System.Windows.Forms.Label();
            this.captionDiem = new System.Windows.Forms.Label();
            this.lblDiem = new System.Windows.Forms.Label();
            this.btnDong = new System.Windows.Forms.Button();
            this.SuspendLayout();
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Location = new System.Drawing.Point(24, 20);
            this.lblTieuDe.Size = new System.Drawing.Size(575, 40);
            this.lblTieuDe.Text = "CHI TIẾT SINH VIÊN";
            this.Controls.Add(this.lblTieuDe);
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.FromArgb(31, 78, 121);
            this.captionMa.Name = "captionMa";
            this.captionMa.Location = new System.Drawing.Point(24, 82);
            this.captionMa.Size = new System.Drawing.Size(150, 28);
            this.captionMa.Text = "Mã sinh viên";
            this.Controls.Add(this.captionMa);
            this.captionMa.ForeColor = System.Drawing.Color.FromArgb(90, 103, 119);
            this.lblMa.Name = "lblMa";
            this.lblMa.Location = new System.Drawing.Point(184, 82);
            this.lblMa.Size = new System.Drawing.Size(410, 28);
            this.lblMa.Text = "—";
            this.Controls.Add(this.lblMa);
            this.lblMa.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblMa.AutoEllipsis = true;
            this.captionTen.Name = "captionTen";
            this.captionTen.Location = new System.Drawing.Point(24, 124);
            this.captionTen.Size = new System.Drawing.Size(150, 28);
            this.captionTen.Text = "Họ và tên";
            this.Controls.Add(this.captionTen);
            this.captionTen.ForeColor = System.Drawing.Color.FromArgb(90, 103, 119);
            this.lblTen.Name = "lblTen";
            this.lblTen.Location = new System.Drawing.Point(184, 124);
            this.lblTen.Size = new System.Drawing.Size(410, 28);
            this.lblTen.Text = "—";
            this.Controls.Add(this.lblTen);
            this.lblTen.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblTen.AutoEllipsis = true;
            this.captionNgay.Name = "captionNgay";
            this.captionNgay.Location = new System.Drawing.Point(24, 166);
            this.captionNgay.Size = new System.Drawing.Size(150, 28);
            this.captionNgay.Text = "Ngày sinh";
            this.Controls.Add(this.captionNgay);
            this.captionNgay.ForeColor = System.Drawing.Color.FromArgb(90, 103, 119);
            this.lblNgay.Name = "lblNgay";
            this.lblNgay.Location = new System.Drawing.Point(184, 166);
            this.lblNgay.Size = new System.Drawing.Size(410, 28);
            this.lblNgay.Text = "—";
            this.Controls.Add(this.lblNgay);
            this.lblNgay.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblNgay.AutoEllipsis = true;
            this.captionGioi.Name = "captionGioi";
            this.captionGioi.Location = new System.Drawing.Point(24, 208);
            this.captionGioi.Size = new System.Drawing.Size(150, 28);
            this.captionGioi.Text = "Giới tính";
            this.Controls.Add(this.captionGioi);
            this.captionGioi.ForeColor = System.Drawing.Color.FromArgb(90, 103, 119);
            this.lblGioi.Name = "lblGioi";
            this.lblGioi.Location = new System.Drawing.Point(184, 208);
            this.lblGioi.Size = new System.Drawing.Size(410, 28);
            this.lblGioi.Text = "—";
            this.Controls.Add(this.lblGioi);
            this.lblGioi.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblGioi.AutoEllipsis = true;
            this.captionKhoa.Name = "captionKhoa";
            this.captionKhoa.Location = new System.Drawing.Point(24, 250);
            this.captionKhoa.Size = new System.Drawing.Size(150, 28);
            this.captionKhoa.Text = "Khoa";
            this.Controls.Add(this.captionKhoa);
            this.captionKhoa.ForeColor = System.Drawing.Color.FromArgb(90, 103, 119);
            this.lblKhoa.Name = "lblKhoa";
            this.lblKhoa.Location = new System.Drawing.Point(184, 250);
            this.lblKhoa.Size = new System.Drawing.Size(410, 28);
            this.lblKhoa.Text = "—";
            this.Controls.Add(this.lblKhoa);
            this.lblKhoa.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblKhoa.AutoEllipsis = true;
            this.captionDiem.Name = "captionDiem";
            this.captionDiem.Location = new System.Drawing.Point(24, 292);
            this.captionDiem.Size = new System.Drawing.Size(150, 28);
            this.captionDiem.Text = "Điểm trung bình";
            this.Controls.Add(this.captionDiem);
            this.captionDiem.ForeColor = System.Drawing.Color.FromArgb(90, 103, 119);
            this.lblDiem.Name = "lblDiem";
            this.lblDiem.Location = new System.Drawing.Point(184, 292);
            this.lblDiem.Size = new System.Drawing.Size(410, 28);
            this.lblDiem.Text = "—";
            this.Controls.Add(this.lblDiem);
            this.lblDiem.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblDiem.AutoEllipsis = true;
            this.btnDong.Name = "btnDong";
            this.btnDong.Location = new System.Drawing.Point(474, 350);
            this.btnDong.Size = new System.Drawing.Size(120, 34);
            this.btnDong.Text = "Đóng";
            this.Controls.Add(this.btnDong);
            this.btnDong.TabIndex = 0;
            this.btnDong.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.AcceptButton = this.btnDong;
            this.CancelButton = this.btnDong;
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(630, 405);
            this.Name = "frmChiTietSinhVien";
            this.Text = "Chi tiết sinh viên";
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ShowInTaskbar = false;
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Label captionMa;
        private System.Windows.Forms.Label lblMa;
        private System.Windows.Forms.Label captionTen;
        private System.Windows.Forms.Label lblTen;
        private System.Windows.Forms.Label captionNgay;
        private System.Windows.Forms.Label lblNgay;
        private System.Windows.Forms.Label captionGioi;
        private System.Windows.Forms.Label lblGioi;
        private System.Windows.Forms.Label captionKhoa;
        private System.Windows.Forms.Label lblKhoa;
        private System.Windows.Forms.Label captionDiem;
        private System.Windows.Forms.Label lblDiem;
        private System.Windows.Forms.Button btnDong;
    }
}
