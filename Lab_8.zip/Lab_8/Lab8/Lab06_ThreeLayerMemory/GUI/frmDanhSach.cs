﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using Lab06_ThreeLayerMemory.BUS;
using Lab06_ThreeLayerMemory.Models;

namespace Lab06_ThreeLayerMemory.GUI
{
    public partial class frmDanhSach : Form
    {
        private readonly SinhVienBUS _sinhVienBUS;
        private readonly KhoaBUS _khoaBUS;

        // BÀI 1: BindingList là bản dữ liệu dùng để hiển thị, không phải kho DAL.
        private readonly BindingList<SinhVien> _ds = new BindingList<SinhVien>();
        private bool _dangDongBo;
        private string _maDangChon;

        public frmDanhSach()
        {
            InitializeComponent();
            bindingSource1.DataSource = _ds;
            dgvSinhVien.DataSource = bindingSource1;
            dgvSinhVien.Columns["colNgaySinh"].DefaultCellStyle.Format = "dd/MM/yyyy";
            dgvSinhVien.Columns["colDiemTB"].DefaultCellStyle.Format = "N2";
            dgvSinhVien.Columns["colDiemTB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }

        public frmDanhSach(SinhVienBUS sinhVienBUS, KhoaBUS khoaBUS) : this()
        {
            _sinhVienBUS = sinhVienBUS;
            _khoaBUS = khoaBUS;
        }

        private void frmDanhSach_Load(object sender, EventArgs e)
        {
            if (_sinhVienBUS != null) NapDuLieu(null);
        }

        public void NapDuLieu(string maCanChon)
        {
            if (_sinhVienBUS == null) return;
            _dangDongBo = true;
            try
            {
                List<SinhVien> duLieu = _sinhVienBUS.GetAll();
                // Gộp thông báo để không vẽ lại giao diện ở từng lần Add.
                _ds.RaiseListChangedEvents = false;
                try
                {
                    _ds.Clear();
                    foreach (SinhVien sv in duLieu) _ds.Add(sv);
                }
                finally
                {
                    _ds.RaiseListChangedEvents = true;
                    _ds.ResetBindings();
                }
                LoadListView(_ds);
                LoadTree(_khoaBUS.GetAll(), _ds);
                lblThongKe.Text = string.Format("{0} sinh viên  •  {1} khoa", _ds.Count, tvKhoa.Nodes.Count);
            }
            finally { _dangDongBo = false; }

            string ma = _ds.Any(s => s.MaSV == maCanChon) ? maCanChon
                : (_ds.Count == 0 ? null : _ds[0].MaSV);
            ChonSinhVien(ma);
        }

        // BÀI 3: Details + đủ 4 cột: mã, họ tên, khoa, điểm.
        private void LoadListView(IEnumerable<SinhVien> data)
        {
            lvSinhVien.BeginUpdate();
            try
            {
                lvSinhVien.Items.Clear();
                lvSinhVien.View = View.Details;
                foreach (SinhVien sv in data)
                {
                    ListViewItem item = new ListViewItem(sv.MaSV);
                    item.SubItems.Add(sv.HoTen);
                    item.SubItems.Add(sv.TenKhoa);
                    item.SubItems.Add(sv.DiemTB.ToString("N2", CultureInfo.CurrentCulture));
                    item.Tag = sv;
                    lvSinhVien.Items.Add(item);
                }
            }
            finally { lvSinhVien.EndUpdate(); }
        }

        // BÀI 4: Tag của node gốc là Khoa; Tag của node con là SinhVien.
        private void LoadTree(IEnumerable<Khoa> cacKhoa, IEnumerable<SinhVien> data)
        {
            tvKhoa.BeginUpdate();
            try
            {
                tvKhoa.Nodes.Clear();
                foreach (Khoa khoa in cacKhoa)
                {
                    List<SinhVien> sinhVienTrongKhoa = data.Where(s => s.MaKhoa == khoa.MaKhoa).ToList();
                    TreeNode khoaNode = new TreeNode(khoa.TenKhoa + " (" + sinhVienTrongKhoa.Count + ")");
                    khoaNode.Tag = khoa;
                    foreach (SinhVien sv in sinhVienTrongKhoa)
                    {
                        TreeNode svNode = new TreeNode(sv.MaSV + " - " + sv.HoTen);
                        svNode.Tag = sv;
                        khoaNode.Nodes.Add(svNode);
                    }
                    tvKhoa.Nodes.Add(khoaNode);
                }
                tvKhoa.ExpandAll(); // Khoa rỗng vẫn hiện node gốc.
            }
            finally { tvKhoa.EndUpdate(); }
        }

        private SinhVien SinhVienDangChon()
        {
            return _ds.FirstOrDefault(sv => sv.MaSV == _maDangChon);
        }

        // Đồng bộ vùng chọn giữa DataGridView, ListView và TreeView.
        private void ChonSinhVien(string maSV)
        {
            if (_dangDongBo) return;
            _dangDongBo = true;
            try
            {
                _maDangChon = maSV;
                SinhVien sv = SinhVienDangChon();
                dgvSinhVien.ClearSelection();
                if (sv == null) dgvSinhVien.CurrentCell = null;
                foreach (DataGridViewRow row in dgvSinhVien.Rows)
                {
                    SinhVien rowData = row.DataBoundItem as SinhVien;
                    if (sv != null && rowData != null && rowData.MaSV == sv.MaSV)
                    {
                        dgvSinhVien.CurrentCell = row.Cells[0];
                        row.Selected = true;
                        break;
                    }
                }

                foreach (ListViewItem item in lvSinhVien.Items)
                {
                    SinhVien itemData = item.Tag as SinhVien;
                    item.Selected = sv != null && itemData != null && itemData.MaSV == sv.MaSV;
                    if (item.Selected) item.EnsureVisible();
                }

                if (sv != null)
                {
                    foreach (TreeNode khoaNode in tvKhoa.Nodes)
                        foreach (TreeNode node in khoaNode.Nodes)
                        {
                            SinhVien nodeData = node.Tag as SinhVien;
                            if (nodeData != null && nodeData.MaSV == sv.MaSV)
                            {
                                tvKhoa.SelectedNode = node;
                                node.EnsureVisible();
                            }
                        }
                }
                else if (tvKhoa.SelectedNode != null && tvKhoa.SelectedNode.Tag is SinhVien)
                    tvKhoa.SelectedNode = null;

                btnSua.Enabled = btnXoa.Enabled = btnChiTiet.Enabled = sv != null;
                lblChiTiet.Text = sv == null ? "Chưa chọn sinh viên. Bấm Thêm để nhập sinh viên mới."
                    : string.Format("{0} • {1}\nNgày sinh: {2:dd/MM/yyyy}  |  {3}  |  {4}  |  Điểm TB: {5:N2}",
                        sv.MaSV, sv.HoTen, sv.NgaySinh, sv.GioiTinh, sv.TenKhoa, sv.DiemTB);
            }
            finally { _dangDongBo = false; }
        }

        private void dgvSinhVien_SelectionChanged(object sender, EventArgs e)
        {
            if (_dangDongBo || dgvSinhVien.CurrentRow == null) return;
            SinhVien sv = dgvSinhVien.CurrentRow.DataBoundItem as SinhVien;
            if (sv != null) ChonSinhVien(sv.MaSV);
        }

        private void lvSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_dangDongBo || lvSinhVien.SelectedItems.Count == 0) return;
            SinhVien sv = lvSinhVien.SelectedItems[0].Tag as SinhVien;
            if (sv != null) ChonSinhVien(sv.MaSV);
        }

        private void tvKhoa_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (_dangDongBo) return;
            SinhVien sv = e.Node.Tag as SinhVien;
            if (sv != null) ChonSinhVien(sv.MaSV);
            else
            {
                ChonSinhVien(null);
                Khoa khoa = e.Node.Tag as Khoa;
                if (khoa != null)
                    lblChiTiet.Text = khoa.TenKhoa + "\nCó " + e.Node.Nodes.Count + " sinh viên. Chọn một node con để xem chi tiết.";
            }
        }

        // BÀI 2 + BÀI 5: CRUD qua BUS, sau đó nạp lại cả 3 vùng hiển thị.
        public void ThemSinhVien()
        {
            if (_sinhVienBUS == null) return;
            using (frmSinhVien form = new frmSinhVien(_sinhVienBUS, _khoaBUS, null))
                if (form.ShowDialog(this) == DialogResult.OK) NapDuLieu(form.MaDaLuu);
        }

        private void btnThem_Click(object sender, EventArgs e) { ThemSinhVien(); }

        private void btnSua_Click(object sender, EventArgs e)
        {
            SinhVien sv = SinhVienDangChon();
            if (sv == null) return;
            using (frmSinhVien form = new frmSinhVien(_sinhVienBUS, _khoaBUS, sv))
                if (form.ShowDialog(this) == DialogResult.OK) NapDuLieu(form.MaDaLuu);
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            SinhVien sv = SinhVienDangChon();
            if (sv == null) return;
            if (MessageBox.Show(this, "Xóa " + sv.MaSV + " - " + sv.HoTen + "?", "Xác nhận xóa",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                != DialogResult.Yes) return;
            try
            {
                _sinhVienBUS.Delete(sv.MaSV);
                NapDuLieu(null);
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(this, ex.Message, "Không thể xóa", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                NapDuLieu(null);
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e) { NapDuLieu(_maDangChon); }

        private void btnChiTiet_Click(object sender, EventArgs e)
        {
            SinhVien sv = SinhVienDangChon();
            if (sv == null) return;
            using (frmChiTietSinhVien form = new frmChiTietSinhVien(sv)) form.ShowDialog(this);
        }

        private void dgvSinhVien_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) btnChiTiet_Click(sender, EventArgs.Empty);
        }

        private void lvSinhVien_DoubleClick(object sender, EventArgs e) { btnChiTiet_Click(sender, e); }

        private void tvKhoa_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            SinhVien sv = e.Node.Tag as SinhVien;
            if (sv == null) return;
            ChonSinhVien(sv.MaSV);
            btnChiTiet_Click(sender, EventArgs.Empty);
        }
    }
}
