﻿using System.Collections.Generic;
using System.Linq;
using Lab06_ThreeLayerMemory.Models;

namespace Lab06_ThreeLayerMemory.DAL
{
    public class KhoaDAL : IKhoaDAL
    {
        private readonly List<Khoa> _data = new List<Khoa>
        {
            new Khoa("CNTT", "Công nghệ thông tin"),
            new Khoa("OTO", "Công nghệ kỹ thuật ô tô"),
            new Khoa("KT", "Kinh tế")
        };

        public List<Khoa> GetAll()
        {
            return _data.Select(k => k.SaoChep()).ToList();
        }
    }
}
