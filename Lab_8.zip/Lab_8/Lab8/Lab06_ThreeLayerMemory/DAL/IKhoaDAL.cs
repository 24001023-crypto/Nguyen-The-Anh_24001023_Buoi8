﻿using System.Collections.Generic;
using Lab06_ThreeLayerMemory.Models;

namespace Lab06_ThreeLayerMemory.DAL
{
    public interface IKhoaDAL
    {
        List<Khoa> GetAll();
    }
}
