﻿using System;
using System.Collections.Generic;
using System.Linq;
using Lab06_ThreeLayerMemory.DAL;
using Lab06_ThreeLayerMemory.Models;

namespace Lab06_ThreeLayerMemory.BUS
{
    public class SinhVienBUS
    {
        private readonly ISinhVienDAL _dal;
        private readonly IKhoaDAL _khoaDAL;

        public SinhVienBUS(ISinhVienDAL dal, IKhoaDAL khoaDAL)
        {
            if (dal == null) throw new ArgumentNullException("dal");
            if (khoaDAL == null) throw new ArgumentNullException("khoaDAL");
            _dal = dal;
            _khoaDAL = khoaDAL;
        }

        public List<SinhVien> GetAll()
        {
            List<Khoa> cacKhoa = _khoaDAL.GetAll();
            List<SinhVien> danhSach = _dal.GetAll();
            foreach (SinhVien sv in danhSach)
            {
                Khoa khoa = cacKhoa.FirstOrDefault(k => k.MaKhoa == sv.MaKhoa);
                sv.TenKhoa = khoa == null ? "Không xác định" : khoa.TenKhoa;
            }
            return danhSach;
        }

        public SinhVien GetById(string maSV)
        {
            string ma = ChuanHoaMa(maSV);
            return GetAll().FirstOrDefault(sv => sv.MaSV == ma);
        }

        public void Add(SinhVien sv)
        {
            SinhVien hopLe = ChuanHoaVaKiemTra(sv);
            if (_dal.GetById(hopLe.MaSV) != null)
                throw new ArgumentException("Mã sinh viên đã tồn tại.", "MaSV");
            _dal.Add(hopLe);
        }

        public void Update(string maGoc, SinhVien sv)
        {
            SinhVien hopLe = ChuanHoaVaKiemTra(sv);
            if (hopLe.MaSV != ChuanHoaMa(maGoc))
                throw new ArgumentException("Không được đổi mã sinh viên khi sửa.", "MaSV");
            if (_dal.GetById(hopLe.MaSV) == null)
                throw new InvalidOperationException("Không tìm thấy sinh viên cần sửa.");
            _dal.Update(hopLe);
        }

        public void Delete(string maSV)
        {
            string ma = ChuanHoaMa(maSV);
            if (_dal.GetById(ma) == null)
                throw new InvalidOperationException("Không tìm thấy sinh viên cần xóa.");
            _dal.Delete(ma);
        }

        private static string ChuanHoaMa(string ma)
        {
            return (ma ?? "").Trim().ToUpperInvariant();
        }

        private SinhVien ChuanHoaVaKiemTra(SinhVien sv)
        {
            if (sv == null) throw new ArgumentNullException("sv");

            // Kiểm tra trên bản sao; lỗi không làm thay đổi dữ liệu đang hiển thị.
            SinhVien kq = sv.SaoChep();
            kq.MaSV = ChuanHoaMa(kq.MaSV);
            kq.HoTen = (kq.HoTen ?? "").Trim();
            kq.MaKhoa = ChuanHoaMa(kq.MaKhoa);
            kq.GioiTinh = (kq.GioiTinh ?? "").Trim();
            kq.NgaySinh = kq.NgaySinh.Date;

            if (kq.MaSV.Length == 0 || kq.MaSV.Length > 20)
                throw new ArgumentException("Mã sinh viên phải có từ 1 đến 20 ký tự.", "MaSV");
            if (kq.HoTen.Length == 0 || kq.HoTen.Length > 100)
                throw new ArgumentException("Họ tên phải có từ 1 đến 100 ký tự.", "HoTen");
            if (kq.NgaySinh < new DateTime(1900, 1, 1) || kq.NgaySinh > DateTime.Today)
                throw new ArgumentException("Ngày sinh phải từ 01/01/1900 đến hôm nay.", "NgaySinh");
            if (kq.GioiTinh != "Nam" && kq.GioiTinh != "Nữ")
                throw new ArgumentException("Vui lòng chọn giới tính Nam hoặc Nữ.", "GioiTinh");
            if (!_khoaDAL.GetAll().Any(k => k.MaKhoa == kq.MaKhoa))
                throw new ArgumentException("Vui lòng chọn một khoa hợp lệ.", "MaKhoa");
            if (double.IsNaN(kq.DiemTB) || double.IsInfinity(kq.DiemTB)
                || kq.DiemTB < 0 || kq.DiemTB > 10)
                throw new ArgumentException("Điểm trung bình phải từ 0 đến 10.", "DiemTB");

            // Tên khoa hiển thị được BUS tra theo mã, không nhận từ ô nhập.
            kq.TenKhoa = "";
            return kq;
        }
    }
}
