﻿using System;
using System.Collections.Generic;
using Lab06_ThreeLayerMemory.DAL;
using Lab06_ThreeLayerMemory.Models;

namespace Lab06_ThreeLayerMemory.BUS
{
    public class KhoaBUS
    {
        private readonly IKhoaDAL _dal;

        public KhoaBUS(IKhoaDAL dal)
        {
            if (dal == null) throw new ArgumentNullException("dal");
            _dal = dal;
        }

        public List<Khoa> GetAll()
        {
            return _dal.GetAll();
        }
    }
}
