# Giải thích code Lab 6

## 1. Em tổ chức chương trình như thế nào?

“Em chia ứng dụng thành GUI, BUS và DAL. GUI nhận dữ liệu người dùng và hiển thị kết quả. BUS kiểm tra nghiệp vụ. DAL lưu danh sách sinh viên trong bộ nhớ. Các lớp SinhVien và Khoa nằm trong Models để các tầng cùng sử dụng.”

Ví dụ khi thêm sinh viên: nút Lưu trên `frmSinhVien` tạo đối tượng `SinhVien`, gọi `SinhVienBUS.Add()`. BUS kiểm tra mã, họ tên, ngày sinh, khoa, điểm và trùng mã. Nếu hợp lệ, BUS gọi `SinhVienDAL.Add()`. Form danh sách sau đó nạp lại dữ liệu và cập nhật cả ba cách hiển thị.

## 2. BindingList và BindingSource dùng làm gì?

```csharp
private readonly BindingList<SinhVien> _ds = new BindingList<SinhVien>();
```

- `BindingList<SinhVien>` là danh sách sinh viên có thông báo thay đổi danh sách cho điều khiển liên kết dữ liệu.
- `_ds` giữ dữ liệu phục vụ hiển thị trên Form.
- `readonly` ngăn gán `_ds` sang một danh sách khác; vẫn có thể thêm/xóa phần tử.

```csharp
bindingSource1.DataSource = _ds;
dgvSinhVien.DataSource = bindingSource1;
```

`BindingSource` làm trung gian giữa `_ds` và DataGridView. DataGridView lấy dữ liệu qua BindingSource. Sau CRUD, chương trình lấy bản dữ liệu mới từ BUS và cập nhật lại `_ds`.

```csharp
_ds.RaiseListChangedEvents = false;
// Clear và Add các bản ghi do BUS trả về.
_ds.RaiseListChangedEvents = true;
_ds.ResetBindings();
```

Tạm ngừng phát thông báo để tránh vẽ lại ở từng lần thêm. Sau cùng, `ResetBindings()` yêu cầu điều khiển đọc lại danh sách. Mã dùng `try/finally` để luôn bật lại thông báo khi kết thúc.

**Lưu ý:** Model này không cài `INotifyPropertyChanged`. Nếu tự sửa trực tiếp một thuộc tính trên đối tượng trong `_ds`, không nên giả định giao diện sẽ tự nhận biết. Chương trình sửa qua BUS rồi nạp lại dữ liệu và gọi `ResetBindings()`.

## 3. Vì sao tắt AutoGenerateColumns?

```csharp
dgvSinhVien.AutoGenerateColumns = false;
```

Để tự chọn thứ tự cột, tiêu đề tiếng Việt và thuộc tính được hiển thị. Ví dụ cột có `HeaderText = "Họ và tên"` và `DataPropertyName = "HoTen"` sẽ lấy giá trị từ thuộc tính `HoTen` của từng sinh viên.

`FullRowSelect` chọn cả dòng; `MultiSelect = false` chỉ chọn một sinh viên. `ReadOnly = true` yêu cầu người dùng bấm Sửa và Lưu qua BUS, bảo đảm mọi thay đổi đều được kiểm tra.

## 4. Lấy sinh viên từ dòng bảng như thế nào?

```csharp
SinhVien sv = dgvSinhVien.CurrentRow.DataBoundItem as SinhVien;
```

`CurrentRow` là dòng hiện tại. `DataBoundItem` là đối tượng dữ liệu gắn với dòng đó. `as SinhVien` ép về kiểu SinhVien; nếu không phù hợp sẽ trả về null. Trong chương trình có kiểm tra dòng và đối tượng trước khi sử dụng.

## 5. ListView dùng Items, SubItems và Tag ra sao?

```csharp
ListViewItem item = new ListViewItem(sv.MaSV);
item.SubItems.Add(sv.HoTen);
item.SubItems.Add(sv.TenKhoa);
item.SubItems.Add(sv.DiemTB.ToString("N2"));
item.Tag = sv;
lvSinhVien.Items.Add(item);
```

Mã sinh viên là cột đầu tiên; các `SubItems` tiếp theo lần lượt là tên, khoa, điểm. `N2` định dạng số với 2 chữ số thập phân. `Tag` lưu đối tượng SinhVien để lấy lại khi chọn dòng; không cần tách mã từ chuỗi hiển thị.

`View.Details` hiển thị thành hàng/cột. Mỗi lần nạp lại gọi `Items.Clear()` trước để tránh lặp sinh viên.

## 6. TreeView được tạo như thế nào?

Mỗi khoa có một node gốc; từng sinh viên có node con. Chương trình lấy sinh viên theo `MaKhoa`, không nhóm dựa vào chuỗi tên đang hiển thị.

```csharp
TreeNode svNode = new TreeNode(sv.MaSV + " - " + sv.HoTen);
svNode.Tag = sv;
khoaNode.Nodes.Add(svNode);
```

`AfterSelect` chạy khi chọn node. Nếu `Tag` là SinhVien, chương trình chọn cùng sinh viên ở bảng và ListView, đồng thời hiển thị chi tiết phía dưới. Nếu là Khoa, chương trình hiển thị số sinh viên của khoa. Khoa chưa có sinh viên vẫn giữ node gốc.

Biến `_dangDongBo` ngăn việc thay đổi vùng chọn ở một điều khiển tiếp tục kích hoạt đồng bộ lặp qua các điều khiển khác.

## 7. Vì sao kiểm tra trùng mã trong BUS?

```csharp
if (_dal.GetById(hopLe.MaSV) != null)
    throw new ArgumentException("Mã sinh viên đã tồn tại.", "MaSV");
```

Trùng mã là quy tắc nghiệp vụ. Đặt ở BUS giúp mọi giao diện gọi BUS đều phải tuân thủ quy tắc này. Mã được Trim và chuyển thành chữ hoa, vì vậy `sv01`, `SV01` và ` SV01 ` được xem là cùng mã.

BUS cũng kiểm tra điểm 0–10, chặn NaN/vô cực, bắt buộc họ tên, kiểm tra ngày sinh và khoa tồn tại. GUI chỉ kiểm tra chuyển chuỗi điểm thành số bằng `TryParse`, rồi giao các quy tắc còn lại cho BUS.

## 8. Vì sao DAL trả bản sao?

Nếu trả danh sách gốc, Form có thể tự thêm/xóa mà bỏ qua BUS. Nếu chỉ tạo danh sách mới nhưng dùng lại các đối tượng cũ, Form vẫn có thể sửa thuộc tính của sinh viên đang lưu.

```csharp
return _data.Select(sv => sv.SaoChep()).ToList();
```

Câu lệnh tạo danh sách mới và sao chép từng sinh viên. Để lưu sửa đổi, Form phải gọi BUS rồi DAL. Trường hợp bấm Hủy trên Form sửa sẽ không làm đổi dữ liệu gốc.

## 9. Vì sao không new DAL trong mỗi nút bấm?

Mỗi đối tượng DAL bộ nhớ có danh sách riêng. Nếu mỗi nút tạo DAL mới, dữ liệu vừa thêm có thể không xuất hiện ở lần đọc kế tiếp. Vì vậy `Program.cs` tạo một DAL và truyền nó vào BUS; các Form dùng chung BUS trong suốt phiên chạy.

## 10. Sang Lab 7 thay gì?

“Em giữ cách Form gọi BUS và giữ các model. Em tạo DAL SQL thực hiện các interface hiện có, thay các thao tác trên List bằng câu lệnh ADO.NET. Sau đó em thay đối tượng DAL được tạo ở Program.cs và bổ sung xử lý lỗi kết nối.”

Interface mô tả những phương thức DAL phải có. BUS phụ thuộc vào hợp đồng `ISinhVienDAL`, không gắn chặt với một cách lưu trong bộ nhớ.
