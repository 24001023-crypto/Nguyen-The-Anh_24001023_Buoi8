# Kết quả kiểm tra

## Đã thực hiện

- Biên dịch toàn bộ 19 file C# bằng Mono C# Compiler 6.8: thành công, không có cảnh báo.
- Chạy 51 kiểm tra tự động về nghiệp vụ và các điều khiển Windows Forms: đạt 51/51.
- Kiểm tra các tham chiếu file trong `.csproj`, 5 file `.resx`, và việc GUI không tham chiếu DAL trực tiếp.
- Chạy giao diện trên Mono với màn hình ảo và xem ảnh thực tế của Form chính, ListView, Form nhập và Form chi tiết.

## Nhóm tình huống đã kiểm tra

| Nhóm | Nội dung |
|---|---|
| Dữ liệu ban đầu | 3 khoa, 9 sinh viên, mỗi khoa 3 sinh viên; tên khoa được tra đúng. |
| Bảo vệ dữ liệu | Dữ liệu trả về và dữ liệu nhập được sao chép; sửa bản sao không sửa kho gốc. |
| Thêm | Chuẩn hóa mã, bỏ khoảng trắng đầu/cuối, chặn trùng mã khác hoa/thường. |
| Ràng buộc | Chặn mã/tên trống, khoa sai, ngày sinh tương lai, điểm ngoài 0–10, NaN, vô cực. |
| Sửa | Thay khoa/điểm; chấp nhận 0 và 10; giữ dữ liệu cũ khi sửa không hợp lệ; không cho đổi mã. |
| Xóa tại BUS/DAL | Xóa bản ghi, chặn mã không tồn tại, nạp lại các điều khiển sau khi dữ liệu thay đổi. |
| Chọn sinh viên | Chọn trên cây, bảng hoặc ListView sẽ đồng bộ vùng chọn và vùng chi tiết. |
| Form nhập | Nhập chữ vào điểm không gây dừng chương trình; nhận điểm dạng 8,5; lỗi trùng mã hiện trên Form; Hủy không lưu. |
| Cập nhật hiển thị | Thêm và sửa qua Form rồi nạp lại đủ ba vùng; đổi khoa chuyển node sang khoa mới. |
| Danh sách rỗng | Vẫn giữ 3 khoa, tắt Sửa/Xóa, có thể thêm sinh viên mới. |
| Vòng đời | Khởi tạo kho dữ liệu mới sẽ có lại 9 sinh viên mẫu. |

## Phạm vi xác minh

Project đích là **Windows Forms .NET Framework 4.8 trên Visual Studio 2022**. Môi trường kiểm tra ở đây dùng Mono trên Linux; chưa chạy trực tiếp trong Visual Studio 2022 trên Windows. Giao diện chuẩn của Windows có thể khác màu/kiểu viền so với Mono.

Khi mở trên máy Windows, có thể dùng kịch bản demo trong README để kiểm tra thêm hộp thoại xác nhận Xóa, Thoát và mở từng Form trong Designer.
