﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Windows.Forms;

namespace Lab07_ADONET_Connection
{
    public partial class frmLab8 : Form
    {
        private void label9_Click(object sender, EventArgs e)
        {
            // Chưa cần xử lý sự kiện này
        }
        public frmLab8()
        {
            InitializeComponent();

            // Gắn sự kiện cho các nút
            btnDem.Click += btnDem_Click;
            btnDoc.Click += btnDoc_Click;
            btnThem.Click += btnThem_Click;
            btnCapNhat.Click += btnCapNhat_Click;
            btnTimKhoa.Click += btnTimKhoa_Click;
        }

        // Đọc điểm, chấp nhận cả 8.5 và 8,5
        private decimal LayDiem()
        {
            string s = txtDiemTB.Text.Trim().Replace(',', '.');

            decimal diem;
            if (!decimal.TryParse(
                s,
                NumberStyles.Number,
                CultureInfo.InvariantCulture,
                out diem) || diem < 0 || diem > 10)
            {
                throw new Exception("Điểm phải nằm trong khoảng từ 0 đến 10.");
            }

            return diem;
        }

        // 1. ExecuteScalar: Đếm số sinh viên
        private void btnDem_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = DbConnectionFactory.Create())
                using (SqlCommand cmd = new SqlCommand(
                    "SELECT COUNT(*) FROM SinhVien", conn))
                {
                    conn.Open();

                    int soLuong = Convert.ToInt32(cmd.ExecuteScalar());

                    MessageBox.Show(
                        "Tổng số sinh viên: " + soLuong,
                        "Thống kê",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi đếm sinh viên: " + ex.Message);
            }
        }

        // 2. ExecuteReader: Đọc danh sách sinh viên
        private void btnDoc_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = DbConnectionFactory.Create())
                using (SqlCommand cmd = new SqlCommand(
                    @"SELECT MaSV, HoTen, DiemTB
                      FROM SinhVien
                      ORDER BY HoTen", conn))
                {
                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        lstSinhVien.Items.Clear();

                        while (reader.Read())
                        {
                            string maSV = reader["MaSV"].ToString();
                            string hoTen = reader["HoTen"].ToString();

                            string diem = reader["DiemTB"] == DBNull.Value
                                ? "Chưa có điểm"
                                : Convert.ToDecimal(reader["DiemTB"])
                                    .ToString("N2");

                            lstSinhVien.Items.Add(
                                maSV + " - " + hoTen + " - " + diem);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi đọc danh sách: " + ex.Message);
            }
        }

        // 3. ExecuteNonQuery: Thêm sinh viên
        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMaSV.Text) ||
                    string.IsNullOrWhiteSpace(txtHoTen.Text) ||
                    string.IsNullOrWhiteSpace(txtMaKhoa.Text))
                {
                    MessageBox.Show(
                        "Vui lòng nhập mã sinh viên, họ tên và mã khoa.");
                    return;
                }

                decimal diem = LayDiem();

                string sql = @"
                    INSERT INTO SinhVien
                    (MaSV, HoTen, NgaySinh, GioiTinh,
                     MaKhoa, DiemTB, Email)
                    VALUES
                    (@MaSV, @HoTen, @NgaySinh, @GioiTinh,
                     @MaKhoa, @DiemTB, @Email)";

                using (SqlConnection conn = DbConnectionFactory.Create())
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.Add("@MaSV", SqlDbType.VarChar, 15)
                        .Value = txtMaSV.Text.Trim();

                    cmd.Parameters.Add("@HoTen", SqlDbType.NVarChar, 100)
                        .Value = txtHoTen.Text.Trim();

                    cmd.Parameters.Add("@NgaySinh", SqlDbType.Date)
                        .Value = dtpNgaySinh.Value.Date;

                    cmd.Parameters.Add("@GioiTinh", SqlDbType.Bit)
                        .Value = chkNam.Checked;

                    cmd.Parameters.Add("@MaKhoa", SqlDbType.VarChar, 10)
                        .Value = txtMaKhoa.Text.Trim();

                    SqlParameter pDiem =
                        cmd.Parameters.Add("@DiemTB", SqlDbType.Decimal);
                    pDiem.Precision = 4;
                    pDiem.Scale = 2;
                    pDiem.Value = diem;

                    cmd.Parameters.Add("@Email", SqlDbType.VarChar, 100)
                        .Value = DBNull.Value;

                    conn.Open();

                    int rows = cmd.ExecuteNonQuery();

                    MessageBox.Show("Đã thêm " + rows + " sinh viên.");

                    btnDoc_Click(sender, e);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi SQL khi thêm sinh viên: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể thêm sinh viên: " + ex.Message);
            }
        }

        // 4. SqlParameter: Cập nhật điểm theo mã sinh viên
        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMaSV.Text))
                {
                    MessageBox.Show("Vui lòng nhập mã sinh viên cần cập nhật.");
                    return;
                }

                decimal diem = LayDiem();

                string sql = @"
                    UPDATE SinhVien
                    SET DiemTB = @DiemTB
                    WHERE MaSV = @MaSV";

                using (SqlConnection conn = DbConnectionFactory.Create())
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    SqlParameter pDiem =
                        cmd.Parameters.Add("@DiemTB", SqlDbType.Decimal);
                    pDiem.Precision = 4;
                    pDiem.Scale = 2;
                    pDiem.Value = diem;

                    cmd.Parameters.Add("@MaSV", SqlDbType.VarChar, 15)
                        .Value = txtMaSV.Text.Trim();

                    conn.Open();

                    int rows = cmd.ExecuteNonQuery();

                    MessageBox.Show(
                        rows > 0
                            ? "Cập nhật điểm thành công!"
                            : "Không tìm thấy mã sinh viên.");

                    btnDoc_Click(sender, e);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi cập nhật điểm: " + ex.Message);
            }
        }

        // 5. Stored Procedure: Tìm sinh viên theo khoa
        private void btnTimKhoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMaKhoaTim.Text))
                {
                    MessageBox.Show("Vui lòng nhập mã khoa cần tìm.");
                    return;
                }

                using (SqlConnection conn = DbConnectionFactory.Create())
                using (SqlCommand cmd = new SqlCommand(
                    "sp_SinhVien_TheoKhoa", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@MaKhoa", SqlDbType.VarChar, 10)
                        .Value = txtMaKhoaTim.Text.Trim();

                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        lstSinhVien.Items.Clear();

                        while (reader.Read())
                        {
                            string maSV = reader["MaSV"].ToString();
                            string hoTen = reader["HoTen"].ToString();

                            string diem = reader["DiemTB"] == DBNull.Value
                                ? "Chưa có điểm"
                                : Convert.ToDecimal(reader["DiemTB"])
                                    .ToString("N2");

                            lstSinhVien.Items.Add(
                                maSV + " - " + hoTen + " - " + diem);
                        }

                        if (lstSinhVien.Items.Count == 0)
                        {
                            MessageBox.Show(
                                "Không tìm thấy sinh viên thuộc khoa này.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tìm sinh viên theo khoa: " + ex.Message);
            }
        }
    }
}