﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Lab06_ThreeLayerMemory.DAL;
using Lab06_ThreeLayerMemory.Models;
using Lab07_ADONET_Connection;

namespace Lab07_ADONET_Connection.DAL
{
    public class SinhVienSqlDAL : ISinhVienDAL
    {
        public List<SinhVien> GetAll()
        {
            List<SinhVien> danhSach = new List<SinhVien>();

            using (SqlConnection conn = DbConnectionFactory.Create())
            {
                string sql = @"
                    SELECT MaSV, HoTen, NgaySinh, GioiTinh,
                           MaKhoa, DiemTB
                    FROM SinhVien";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            SinhVien sv = new SinhVien();

                            sv.MaSV = reader["MaSV"].ToString();
                            sv.HoTen = reader["HoTen"].ToString();

                            if (reader["NgaySinh"] != DBNull.Value)
                                sv.NgaySinh = Convert.ToDateTime(
                                    reader["NgaySinh"]);

                            sv.GioiTinh = reader["GioiTinh"].ToString();
                            sv.MaKhoa = reader["MaKhoa"].ToString();

                            if (reader["DiemTB"] != DBNull.Value)
                                sv.DiemTB = Convert.ToDouble(
                                    reader["DiemTB"]);

                            danhSach.Add(sv);
                        }
                    }
                }
            }

            return danhSach;
        }

        public SinhVien GetById(string maSV)
        {
            using (SqlConnection conn = DbConnectionFactory.Create())
            {
                string sql = @"
                    SELECT MaSV, HoTen, NgaySinh, GioiTinh,
                           MaKhoa, DiemTB
                    FROM SinhVien
                    WHERE MaSV = @MaSV";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.Add("@MaSV", SqlDbType.NVarChar).Value =
                        maSV;

                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            SinhVien sv = new SinhVien();

                            sv.MaSV = reader["MaSV"].ToString();
                            sv.HoTen = reader["HoTen"].ToString();

                            if (reader["NgaySinh"] != DBNull.Value)
                                sv.NgaySinh = Convert.ToDateTime(
                                    reader["NgaySinh"]);

                            sv.GioiTinh = reader["GioiTinh"].ToString();
                            sv.MaKhoa = reader["MaKhoa"].ToString();

                            if (reader["DiemTB"] != DBNull.Value)
                                sv.DiemTB = Convert.ToDouble(
                                    reader["DiemTB"]);

                            return sv;
                        }
                    }
                }
            }

            return null;
        }

        public void Add(SinhVien sv)
        {
            using (SqlConnection conn = DbConnectionFactory.Create())
            {
                string sql = @"
                    INSERT INTO SinhVien
                    (MaSV, HoTen, NgaySinh, GioiTinh, MaKhoa, DiemTB)
                    VALUES
                    (@MaSV, @HoTen, @NgaySinh, @GioiTinh, @MaKhoa, @DiemTB)";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    AddParameters(cmd, sv);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Update(SinhVien sv)
        {
            using (SqlConnection conn = DbConnectionFactory.Create())
            {
                string sql = @"
                    UPDATE SinhVien SET
                        HoTen = @HoTen,
                        NgaySinh = @NgaySinh,
                        GioiTinh = @GioiTinh,
                        MaKhoa = @MaKhoa,
                        DiemTB = @DiemTB
                    WHERE MaSV = @MaSV";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    AddParameters(cmd, sv);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void Delete(string maSV)
        {
            using (SqlConnection conn = DbConnectionFactory.Create())
            {
                string sql = "DELETE FROM SinhVien WHERE MaSV = @MaSV";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.Add("@MaSV", SqlDbType.NVarChar).Value =
                        maSV;

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void AddParameters(SqlCommand cmd, SinhVien sv)
        {
            cmd.Parameters.Add("@MaSV", SqlDbType.NVarChar).Value =
                sv.MaSV;

            cmd.Parameters.Add("@HoTen", SqlDbType.NVarChar).Value =
                sv.HoTen;

            cmd.Parameters.Add("@NgaySinh", SqlDbType.Date).Value =
                sv.NgaySinh.Date;

            cmd.Parameters.Add("@GioiTinh", SqlDbType.NVarChar).Value =
                sv.GioiTinh;

            cmd.Parameters.Add("@MaKhoa", SqlDbType.NVarChar).Value =
                sv.MaKhoa;

            cmd.Parameters.Add("@DiemTB", SqlDbType.Float).Value =
                sv.DiemTB;
        }
    }
}
