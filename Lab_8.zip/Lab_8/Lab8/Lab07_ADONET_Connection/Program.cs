﻿using System;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;


namespace Lab07_ADONET_Connection
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.Run(new frmLab8());
        }
    }
}