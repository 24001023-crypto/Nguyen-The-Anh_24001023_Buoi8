﻿using Lab06_ThreeLayerMemory.BUS;
using Lab06_ThreeLayerMemory.DAL;
using Lab06_ThreeLayerMemory.GUI;
using Lab07_ADONET_Connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab07_ADONET_Connection
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnKiemTra_Click(object sender, EventArgs e)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection conn =
                       DbConnectionFactory.Create())
                {
                    conn.Open();

                    MessageBox.Show(
                        "Kết nối SQL Server thành công!",
                        "Thông báo",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }

                // Mở lại giao diện Lab 6 sau khi kết nối thành công
                IKhoaDAL khoaDAL = new Lab06_ThreeLayerMemory.DAL.KhoaDAL();

                ISinhVienDAL sinhVienDAL =
                    new Lab07_ADONET_Connection.DAL.SinhVienSqlDAL();

                KhoaBUS khoaBUS = new KhoaBUS(khoaDAL);

                SinhVienBUS sinhVienBUS =
                    new SinhVienBUS(sinhVienDAL, khoaDAL);

                this.Hide();

                using (frmMain frm = new frmMain(sinhVienBUS, khoaBUS))
                {
                    frm.ShowDialog();
                }

                this.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể kết nối hoặc mở dữ liệu:\n" + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}
