﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab07_ADONET_Connection
{
    public static class DbConnectionFactory
    {
        private const string ConnectionString =
            @"Data Source=DESKTOP-16KR6S3;Initial Catalog=QLSinhVien;Integrated Security=True;TrustServerCertificate=True";

        public static SqlConnection Create()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}
